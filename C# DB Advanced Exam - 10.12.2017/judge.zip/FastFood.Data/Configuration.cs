namespace FastFood.Data
{
	public static class Configuration
	{
		public static string ConnectionString = @"Server=ZORO\SQLEXPRESS;Database=FastFood;Trusted_Connection=True";
	}
}